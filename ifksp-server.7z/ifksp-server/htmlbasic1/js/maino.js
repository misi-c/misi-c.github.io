console.log("hello,this is a console message");
let price1 = 5;
let price2 = 6;
let total = price1 + price2;
let userName;
userName="almafa";
userName.replace("a","b");
let amountInput = document.querySelector("input[name='amount-input']");
let price =1200;
let amount =0;
let Number(amount) = parseInt(amountInput.value)*price;

