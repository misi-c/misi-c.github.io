window.addEventListener("resize", function() {
    console.log(this.innerHeight, this.innerWidth);
});
